### System Requirements
Before you install, please validate the system requirements provided here: https://service.jfrog.org/installer/System+Requirements  
​
### How to run
* `./config.sh` # should provide you an interactive install or upgrade
​
### Default credentials for PostgreSQL
username: artifactory
password: password

### MORE DETAILS 
For more details on installation scripts, refer: https://service.jfrog.org/installer/Installing+Artifactory

For more details on  Upgrade scripts, refer: https://service.jfrog.org/installer/Upgrading+Artifactory

For troubleshooting, refer: https://service.jfrog.org/installer/Troubleshooting